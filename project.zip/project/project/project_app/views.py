# registration/views.py
from django.shortcuts import render, redirect
from .forms import RegistrationForm

def register(request):

    # if request.method == 'POST':
    #     form = RegistrationForm(request.POST)
    #     if form.is_valid():
    #         # Handle user registration logic here (e.g., create a new user)
    #         # For simplicity, we will just redirect to a success page
    #         return redirect('registration_success.html')
    # else:
    #     form = RegistrationForm()

    # return render(request, 'registration.html', {'form': form})
    return render(request, 'registration.html')
    


def registration_success(request):
    return render(request,'registration_success.html')
