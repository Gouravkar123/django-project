# registration/urls.py
from django.urls import path
from .views import register, registration_success
from . import views

urlpatterns = [
    path('',register,name='registration'),
    # path('register/', register, name='register'),
    path('registration_success.html', registration_success, name='registration_success'),
]
